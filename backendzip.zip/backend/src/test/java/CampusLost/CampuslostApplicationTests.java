package CampusLost;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampuslostApplicationTests {

	@Test
	void contextLoads() {
	}

}
