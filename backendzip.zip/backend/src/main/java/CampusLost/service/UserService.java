package com.campuslost.service;

import com.campuslost.model.User;
import com.campuslost.repository.UserRepository;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // Register a new user
    public User saveUser(User user) {

        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            throw new IllegalArgumentException(
                "Email is already registered!"
            );
        }

        // Public registration must not create admin accounts
        user.setRole("STUDENT");

        return userRepository.save(user);
    }

    // Login an existing user
    public User loginUser(String email, String password) {
        return userRepository
                .findByEmailAndPassword(email, password)
                .orElse(null);
    }

    // Get the total number of registered users
    public long getTotalUsers() {
        return userRepository.count();
    }
}