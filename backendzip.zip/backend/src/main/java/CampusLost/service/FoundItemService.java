
package com.campuslost.service;

import com.campuslost.model.FoundItem;
import com.campuslost.repository.FoundItemRepository;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FoundItemService {

    private final FoundItemRepository foundItemRepository;

    public FoundItemService(FoundItemRepository foundItemRepository) {
        this.foundItemRepository = foundItemRepository;
    }

    public FoundItem saveFoundItem(FoundItem foundItem) {
        return foundItemRepository.save(foundItem);
    }

    // Return all found items, including RETURNED items,
    // so the details page can display their current status.
    public List<FoundItem> getFoundItems() {
        return foundItemRepository.findAll();
    }

    public FoundItem getFoundItemById(Long id) {
        return foundItemRepository.findById(id).orElse(null);
    }
}
