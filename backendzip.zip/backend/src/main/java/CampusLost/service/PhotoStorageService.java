
package com.campuslost.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Set;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class PhotoStorageService {

    private final Path uploadDirectory =
            Paths.get("uploads").toAbsolutePath().normalize();

    private static final Set<String> ALLOWED_TYPES =
            Set.of("image/jpeg", "image/png", "image/webp", "image/gif");

    public String savePhoto(MultipartFile photo) throws IOException {

        if (photo == null || photo.isEmpty()) {
            return null;
        }

        if (photo.getSize() > 5 * 1024 * 1024) {
            throw new IllegalArgumentException(
                    "Photo must be 5 MB or smaller.");
        }

        String contentType = photo.getContentType();

        if (contentType == null || !ALLOWED_TYPES.contains(contentType)) {
            throw new IllegalArgumentException(
                    "Upload a JPG, PNG, WEBP, or GIF image.");
        }

        Files.createDirectories(uploadDirectory);

        String extension;

        switch (contentType) {
            case "image/jpeg" -> extension = ".jpg";
            case "image/png" -> extension = ".png";
            case "image/webp" -> extension = ".webp";
            case "image/gif" -> extension = ".gif";
            default -> throw new IllegalArgumentException("Unsupported image.");
        }

        String filename = UUID.randomUUID() + extension;
        Path destination = uploadDirectory.resolve(filename).normalize();

        if (!destination.startsWith(uploadDirectory)) {
            throw new IllegalArgumentException("Invalid filename.");
        }

        Files.copy(photo.getInputStream(), destination);

        return "/uploads/" + filename;
    }
}
