
package com.campuslost.service;

import com.campuslost.model.Claim;
import com.campuslost.model.Match;
import com.campuslost.model.LostItem;
import com.campuslost.repository.ClaimRepository;
import com.campuslost.repository.MatchRepository;
import com.campuslost.repository.LostItemRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ClaimService {

    private final ClaimRepository claimRepository;
    private final MatchRepository matchRepository;
    private final LostItemRepository lostItemRepository;

    public ClaimService(
            ClaimRepository claimRepository,
            MatchRepository matchRepository,
            LostItemRepository lostItemRepository) {
        this.claimRepository = claimRepository;
        this.matchRepository = matchRepository;
        this.lostItemRepository = lostItemRepository;
    }

    public Claim saveClaim(Claim claim) {
        return claimRepository.save(claim);
    }

    public List<Claim> getAllClaims() {
        return claimRepository.findAll();
    }

    public Claim getClaimById(Long id) {
        return claimRepository.findById(id).orElse(null);
    }

    public List<Claim> getClaimsByEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            return List.of();
        }

        String searchEmail = email.trim();

        return claimRepository.findAll()
                .stream()
                .filter(claim ->
                        claim.getClaimantEmail() != null
                        && claim.getClaimantEmail()
                                .equalsIgnoreCase(searchEmail))
                .collect(Collectors.toList());
    }

    // Mark the lost report linked to a match as RESOLVED.
    @Transactional
    public boolean resolveLostItemForMatch(Long matchId) {
        if (matchId == null) {
            return false;
        }

        Match match = matchRepository.findById(matchId).orElse(null);

        if (match == null || match.getLostItemId() == null) {
            return false;
        }

        LostItem lostItem = lostItemRepository
                .findById(match.getLostItemId())
                .orElse(null);

        if (lostItem == null) {
            return false;
        }

        lostItem.setStatus("RESOLVED");
        lostItemRepository.save(lostItem);

        return true;
    }
}
