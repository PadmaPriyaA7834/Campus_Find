package com.campuslost.service;

import com.campuslost.model.LostItem;
import com.campuslost.repository.LostItemRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class LostItemService {


private final LostItemRepository lostItemRepository;

public LostItemService(LostItemRepository lostItemRepository) {
    this.lostItemRepository = lostItemRepository;
}

public LostItem saveLostItem(LostItem lostItem) {
    return lostItemRepository.save(lostItem);
}

public LostItem getLostItemById(Long id) {
    return lostItemRepository.findById(id).orElse(null);
}

public List<LostItem> getLostItems() {
    return lostItemRepository.findAll();
}

}
