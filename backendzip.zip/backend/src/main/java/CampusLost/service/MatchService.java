
package com.campuslost.service;

import com.campuslost.model.Match;
import com.campuslost.repository.MatchRepository;

import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

@Service
public class MatchService {

    private final MatchRepository matchRepository;

    public MatchService(MatchRepository matchRepository) {
        this.matchRepository = matchRepository;
    }

    public Match saveMatch(Match match) {
        return matchRepository.save(match);
    }

    public List<Match> getAllMatches() {
        return matchRepository.findAll();
    }

    public boolean matchExists(Long lostItemId, Long foundItemId) {
        return matchRepository.existsByLostItemIdAndFoundItemId(
                lostItemId, foundItemId);
    }

    public int calculateMatchScore(
            String lostItemName,
            String foundItemName,
            String lostCategory,
            String foundCategory,
            String lostLocation,
            String foundLocation,
            String lostDate,
            String foundDate,
            String lostDescription,
            String foundDescription) {

        // Do not match clearly different item names.
        if (!areItemNamesCompatible(lostItemName, foundItemName)) {
            return 0;
        }

        int score = 0;

        if (sameText(lostCategory, foundCategory)) {
            score += 30;
        }

        if (sameText(lostLocation, foundLocation)) {
            score += 25;
        }

        if (sameText(lostDate, foundDate)) {
            score += 20;
        }

        score += calculateDescriptionScore(
                lostDescription, foundDescription);

        return Math.min(score, 100);
    }

    private boolean areItemNamesCompatible(
            String lostName, String foundName) {

        if (lostName == null || foundName == null
                || lostName.trim().isEmpty()
                || foundName.trim().isEmpty()) {
            return false;
        }

        Set<String> lostWords = getMeaningfulWords(lostName);
        Set<String> foundWords = getMeaningfulWords(foundName);

        // Same normalized name is a valid match.
        if (normalize(lostName).equals(normalize(foundName))) {
            return true;
        }

        // Require at least one meaningful shared word.
        lostWords.retainAll(foundWords);
        return !lostWords.isEmpty();
    }

    private Set<String> getMeaningfulWords(String text) {
        Set<String> words = new HashSet<>(
                Arrays.asList(normalize(text).split("\\s+")));

        // Colors alone should not make two items match.
        words.removeAll(Arrays.asList(
                "black", "blue", "red", "green", "white",
                "yellow", "pink", "purple", "brown", "grey",
                "gray", "orange", "silver", "gold", "colour",
                "color", "college", "item", "my", "the", "a",
                "an", "and", "with"
        ));

        return words;
    }

    private int calculateDescriptionScore(
            String first, String second) {

        if (first == null || second == null
                || first.trim().isEmpty()
                || second.trim().isEmpty()) {
            return 0;
        }

        String firstText = normalize(first);
        String secondText = normalize(second);

        if (firstText.equals(secondText)) {
            return 25;
        }

        Set<String> firstWords = new HashSet<>(
                Arrays.asList(firstText.split("\\s+")));

        Set<String> secondWords = new HashSet<>(
                Arrays.asList(secondText.split("\\s+")));

        Set<String> commonWords = new HashSet<>(firstWords);
        commonWords.retainAll(secondWords);

        if (commonWords.isEmpty()) {
            return 0;
        }

        Set<String> allWords = new HashSet<>(firstWords);
        allWords.addAll(secondWords);

        double similarity =
                (double) commonWords.size() / allWords.size();

        return (int) Math.round(similarity * 25);
    }

    private String normalize(String text) {
        return text.toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9\\s]", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private boolean sameText(String first, String second) {
        return first != null && second != null
                && first.trim().equalsIgnoreCase(second.trim());
    }

    public String getMatchStatus(int score) {
        if (score >= 80) {
            return "HIGH MATCH";
        } else if (score >= 60) {
            return "POSSIBLE MATCH";
        } else {
            return "LOW MATCH";
        }
    }
}