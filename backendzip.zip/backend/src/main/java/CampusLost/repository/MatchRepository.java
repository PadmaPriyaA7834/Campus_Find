
package com.campuslost.repository;

import com.campuslost.model.Match;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MatchRepository extends JpaRepository<Match, Long> {

    boolean existsByLostItemIdAndFoundItemId(
            Long lostItemId,
            Long foundItemId
    );
}


