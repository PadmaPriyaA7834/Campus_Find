
package com.campuslost.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class WebConfig {
}
