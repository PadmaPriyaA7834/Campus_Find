package com.campuslost.controller;

import com.campuslost.model.User;
import com.campuslost.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@CrossOrigin(
    origins = {
        "http://127.0.0.1:5500",
        "http://localhost:5500"
    },
    allowCredentials = "true"
)
@RestController
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    // REGISTER USER
    @PostMapping("/api/users")
    public ResponseEntity<?> createUser(@RequestBody User user) {

        try {
            // Public registration must always create a student account
            user.setRole("STUDENT");

            User savedUser = userService.saveUser(user);

            Map<String, Object> response = new HashMap<>();

            response.put("message", "Registration successful!");
            response.put("id", savedUser.getId());
            response.put("name", savedUser.getName());
            response.put("email", savedUser.getEmail());
            response.put("role", savedUser.getRole());

            return ResponseEntity
                    .status(HttpStatus.CREATED)
                    .body(response);

        } catch (IllegalArgumentException e) {

            Map<String, String> error = new HashMap<>();

            error.put("message", e.getMessage());

            return ResponseEntity
                    .status(HttpStatus.CONFLICT)
                    .body(error);
        }
    }

    // LOGIN USER AND CREATE SERVER-SIDE SESSION
    @PostMapping("/api/users/login")
    public ResponseEntity<?> loginUser(
            @RequestBody User user,
            HttpServletRequest request) {

        User loggedInUser = userService.loginUser(
                user.getEmail(),
                user.getPassword()
        );

        if (loggedInUser == null) {

            Map<String, String> error = new HashMap<>();

            error.put(
                    "message",
                    "Invalid email or password!"
            );

            return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body(error);
        }

        // Create a session after successful login
        HttpSession session = request.getSession(true);

        session.setAttribute("userId", loggedInUser.getId());
        session.setAttribute("userRole", loggedInUser.getRole());

        Map<String, Object> response = new HashMap<>();

        response.put("id", loggedInUser.getId());
        response.put("name", loggedInUser.getName());
        response.put("email", loggedInUser.getEmail());
        response.put("role", loggedInUser.getRole());

        return ResponseEntity.ok(response);
    }

    // GET TOTAL REGISTERED USERS
    @GetMapping("/api/users/count")
    public ResponseEntity<Map<String, Long>> getTotalUsers() {

        Map<String, Long> response = new HashMap<>();

        response.put(
                "totalUsers",
                userService.getTotalUsers()
        );

        return ResponseEntity.ok(response);
    }

    // LOGOUT USER
    @PostMapping("/api/users/logout")
    public ResponseEntity<?> logoutUser(HttpServletRequest request) {

        HttpSession session = request.getSession(false);

        if (session != null) {
            session.invalidate();
        }

        Map<String, String> response = new HashMap<>();

        response.put("message", "Logged out successfully!");

        return ResponseEntity.ok(response);
    }

    // CHECK CURRENT SESSION
    @GetMapping("/api/users/me")
    public ResponseEntity<?> getCurrentUser(HttpServletRequest request) {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("userId") == null) {

            Map<String, String> error = new HashMap<>();

            error.put("message", "Not logged in.");

            return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body(error);
        }

        Map<String, Object> response = new HashMap<>();

        response.put("id", session.getAttribute("userId"));
        response.put("role", session.getAttribute("userRole"));

        return ResponseEntity.ok(response);
    }
}