
package com.campuslost.controller;

import com.campuslost.model.LostItem;
import com.campuslost.model.FoundItem;
import com.campuslost.model.Match;
import com.campuslost.service.LostItemService;
import com.campuslost.service.FoundItemService;
import com.campuslost.service.MatchService;
import com.campuslost.service.PhotoStorageService;

import java.io.IOException;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.multipart.MultipartFile;

@CrossOrigin
@RestController
public class LostItemController {

    private final LostItemService lostItemService;
    private final FoundItemService foundItemService;
    private final MatchService matchService;
    private final PhotoStorageService photoStorageService;

    public LostItemController(
            LostItemService lostItemService,
            FoundItemService foundItemService,
            MatchService matchService,
            PhotoStorageService photoStorageService) {

        this.lostItemService = lostItemService;
        this.foundItemService = foundItemService;
        this.matchService = matchService;
        this.photoStorageService = photoStorageService;
    }

    @PostMapping("/api/lost-items")
    public ResponseEntity<?> createLostItem(
            @RequestParam String itemName,
            @RequestParam String category,
            @RequestParam String location,
            @RequestParam String dateLost,
            @RequestParam String description,
            @RequestParam(required = false) String contact,
            @RequestParam(required = false) MultipartFile photo) {

        try {
            LostItem lostItem = new LostItem();

            lostItem.setItemName(itemName.trim());
            lostItem.setCategory(category);
            lostItem.setLocation(location.trim());
            lostItem.setDateLost(dateLost);
            lostItem.setDescription(description.trim());
            lostItem.setContact(contact == null ? "" : contact.trim());
            lostItem.setStatus("LOST");
            lostItem.setPhotoPath(photoStorageService.savePhoto(photo));

            LostItem savedLostItem =
                    lostItemService.saveLostItem(lostItem);

            List<FoundItem> foundItems =
                    foundItemService.getFoundItems();

            for (FoundItem foundItem : foundItems) {
                int score = matchService.calculateMatchScore(
                        savedLostItem.getItemName(),
                        foundItem.getItemName(),
                        savedLostItem.getCategory(),
                        foundItem.getCategory(),
                        savedLostItem.getLocation(),
                        foundItem.getLocation(),
                        savedLostItem.getDateLost(),
                        foundItem.getDateFound(),
                        savedLostItem.getDescription(),
                        foundItem.getDescription()
                );

                if (score >= 60 && !matchService.matchExists(
                        savedLostItem.getId(), foundItem.getId())) {

                    Match match = new Match();
                    match.setLostItemId(savedLostItem.getId());
                    match.setFoundItemId(foundItem.getId());
                    match.setMatchScore(score);
                    match.setMatchStatus(matchService.getMatchStatus(score));
                    matchService.saveMatch(match);
                }
            }

            return ResponseEntity.ok(savedLostItem);

        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Could not save the uploaded photo.");
        }
    }

    @GetMapping("/api/lost-items")
    public List<LostItem> getLostItems() {
        return lostItemService.getLostItems();
    }
}
