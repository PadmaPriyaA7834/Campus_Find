
package com.campuslost.controller;

import com.campuslost.model.Claim;
import com.campuslost.model.FoundItem;
import com.campuslost.model.LostItem;
import com.campuslost.model.Match;
import com.campuslost.service.ClaimService;
import com.campuslost.repository.FoundItemRepository;
import com.campuslost.repository.LostItemRepository;
import com.campuslost.repository.MatchRepository;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@CrossOrigin(
    origins = {
        "http://127.0.0.1:5500",
        "http://localhost:5500"
    },
    allowedHeaders = "*",
    allowCredentials = "true",
    methods = {
        RequestMethod.GET,
        RequestMethod.POST,
        RequestMethod.PATCH,
        RequestMethod.OPTIONS
    }
)
@RestController
@RequestMapping("/api/claims")
public class ClaimController {

    private final ClaimService claimService;
    private final MatchRepository matchRepository;
    private final FoundItemRepository foundItemRepository;
    private final LostItemRepository lostItemRepository;

    public ClaimController(
            ClaimService claimService,
            MatchRepository matchRepository,
            FoundItemRepository foundItemRepository,
            LostItemRepository lostItemRepository) {

        this.claimService = claimService;
        this.matchRepository = matchRepository;
        this.foundItemRepository = foundItemRepository;
        this.lostItemRepository = lostItemRepository;
    }

    // STUDENT: Submit a claim
    @PostMapping
    public ResponseEntity<?> createClaim(
            @RequestBody Claim claim) {

        if (claim.getMatchId() == null
                || claim.getClaimantEmail() == null
                || claim.getClaimantEmail().trim().isEmpty()
                || claim.getProof() == null
                || claim.getProof().trim().isEmpty()) {

            return error(
                    HttpStatus.BAD_REQUEST,
                    "Match ID, email and proof are required."
            );
        }

        Match match = matchRepository
                .findById(claim.getMatchId())
                .orElse(null);

        if (match == null) {
            return error(
                    HttpStatus.NOT_FOUND,
                    "Match not found."
            );
        }

        if (claim.getClaimantName() == null
                || claim.getClaimantName().trim().isEmpty()) {
            claim.setClaimantName("Student");
        }

        claim.setClaimantEmail(
                claim.getClaimantEmail().trim()
        );
        claim.setProof(claim.getProof().trim());
        claim.setStatus("PENDING");

        Claim savedClaim = claimService.saveClaim(claim);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(savedClaim);
    }

    // FINDER: View claims using the contact number
    @GetMapping("/for-finder")
    public ResponseEntity<?> getClaimsForFinder(
            @RequestParam String phone) {

        if (phone == null || phone.trim().isEmpty()) {
            return error(
                    HttpStatus.BAD_REQUEST,
                    "Finder contact phone number is required."
            );
        }

        String finderPhone = phone.trim();

        List<Claim> matchingClaims = claimService
                .getAllClaims()
                .stream()
                .filter(claim -> {
                    if (claim.getMatchId() == null) {
                        return false;
                    }

                    Match match = matchRepository
                            .findById(claim.getMatchId())
                            .orElse(null);

                    if (match == null
                            || match.getFoundItemId() == null) {
                        return false;
                    }

                    FoundItem foundItem = foundItemRepository
                            .findById(match.getFoundItemId())
                            .orElse(null);

                    return foundItem != null
                            && foundItem.getContact() != null
                            && foundItem.getContact().trim()
                                    .equals(finderPhone);
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok(matchingClaims);
    }

    // STUDENT: View claims by email
    @GetMapping("/my")
    public ResponseEntity<?> getMyClaims(
            @RequestParam String email) {

        if (email == null || email.trim().isEmpty()) {
            return error(
                    HttpStatus.BAD_REQUEST,
                    "Email is required."
            );
        }

        return ResponseEntity.ok(
                claimService.getClaimsByEmail(email.trim())
        );
    }

    // FINDER: Accept or reject a claim
    @PatchMapping("/{id}/review")
    public ResponseEntity<?> reviewClaim(
            @PathVariable Long id,
            @RequestParam String phone,
            @RequestBody Map<String, String> requestBody) {

        if (phone == null || phone.trim().isEmpty()) {
            return error(
                    HttpStatus.BAD_REQUEST,
                    "Finder contact phone number is required."
            );
        }

        Claim claim = claimService.getClaimById(id);

        if (claim == null) {
            return error(
                    HttpStatus.NOT_FOUND,
                    "Claim not found."
            );
        }

        // Verify that this claim belongs to an item
        // reported by the finder using the supplied phone.
        ResponseEntity<?> verification = verifyFinder(
                claim, phone.trim()
        );

        if (verification != null) {
            return verification;
        }

        if (!"PENDING".equalsIgnoreCase(claim.getStatus())) {
            return error(
                    HttpStatus.BAD_REQUEST,
                    "Only pending claims can be reviewed."
            );
        }

        String status = requestBody.get("status");

        if (status == null
                || (!"ACCEPTED".equalsIgnoreCase(status)
                && !"REJECTED".equalsIgnoreCase(status))) {

            return error(
                    HttpStatus.BAD_REQUEST,
                    "Status must be ACCEPTED or REJECTED."
            );
        }

        claim.setStatus(status.toUpperCase());

        Claim savedClaim = claimService.saveClaim(claim);

        return ResponseEntity.ok(savedClaim);
    }

    // FINDER: Mark an accepted claim as returned
    @PatchMapping("/{id}/return")
    @Transactional
    public ResponseEntity<?> returnItem(
            @PathVariable Long id,
            @RequestParam String phone) {

        if (phone == null || phone.trim().isEmpty()) {
            return error(
                    HttpStatus.BAD_REQUEST,
                    "Finder contact phone number is required."
            );
        }

        Claim claim = claimService.getClaimById(id);

        if (claim == null) {
            return error(
                    HttpStatus.NOT_FOUND,
                    "Claim not found."
            );
        }

        ResponseEntity<?> verification = verifyFinder(
                claim, phone.trim()
        );

        if (verification != null) {
            return verification;
        }

        if (!"ACCEPTED".equalsIgnoreCase(claim.getStatus())) {
            return error(
                    HttpStatus.BAD_REQUEST,
                    "Only accepted claims can be marked as returned."
            );
        }

        Match match = matchRepository
                .findById(claim.getMatchId())
                .orElse(null);

        if (match == null
                || match.getFoundItemId() == null
                || match.getLostItemId() == null) {
            return error(
                    HttpStatus.BAD_REQUEST,
                    "The match is missing a linked item ID."
            );
        }

        FoundItem foundItem = foundItemRepository
                .findById(match.getFoundItemId())
                .orElse(null);

        if (foundItem == null) {
            return error(
                    HttpStatus.NOT_FOUND,
                    "Found item not found."
            );
        }

        LostItem lostItem = lostItemRepository
                .findById(match.getLostItemId())
                .orElse(null);

        if (lostItem == null) {
            return error(
                    HttpStatus.NOT_FOUND,
                    "Related lost item not found."
            );
        }

        foundItem.setStatus("RETURNED");
        foundItemRepository.save(foundItem);

        lostItem.setStatus("RESOLVED");
        lostItemRepository.save(lostItem);

        claim.setStatus("RETURNED");

        Claim savedClaim = claimService.saveClaim(claim);

        return ResponseEntity.ok(savedClaim);
    }

    // Verify the finder owns the found-item report
    private ResponseEntity<?> verifyFinder(
            Claim claim,
            String phone) {

        if (claim.getMatchId() == null) {
            return error(
                    HttpStatus.NOT_FOUND,
                    "Match not found."
            );
        }

        Match match = matchRepository
                .findById(claim.getMatchId())
                .orElse(null);

        if (match == null || match.getFoundItemId() == null) {
            return error(
                    HttpStatus.NOT_FOUND,
                    "Found item match not found."
            );
        }

        FoundItem foundItem = foundItemRepository
                .findById(match.getFoundItemId())
                .orElse(null);

        if (foundItem == null) {
            return error(
                    HttpStatus.NOT_FOUND,
                    "Found item not found."
            );
        }

        if (foundItem.getContact() == null
                || !Objects.equals(
                        foundItem.getContact().trim(),
                        phone)) {

            return error(
                    HttpStatus.FORBIDDEN,
                    "Phone number does not match the finder contact."
            );
        }

        return null;
    }

    // Standard error response
    private ResponseEntity<Map<String, String>> error(
            HttpStatus status,
            String message) {

        return ResponseEntity.status(status)
                .body(Map.of("message", message));
    }
}
