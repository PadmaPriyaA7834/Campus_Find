
package com.campuslost.controller;

import com.campuslost.model.Match;
import com.campuslost.model.LostItem;
import com.campuslost.model.FoundItem;

import com.campuslost.service.MatchService;
import com.campuslost.service.LostItemService;
import com.campuslost.service.FoundItemService;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@CrossOrigin
@RestController
public class MatchController {

    private final MatchService matchService;
    private final LostItemService lostItemService;
    private final FoundItemService foundItemService;

    public MatchController(
            MatchService matchService,
            LostItemService lostItemService,
            FoundItemService foundItemService) {

        this.matchService = matchService;
        this.lostItemService = lostItemService;
        this.foundItemService = foundItemService;
    }

    @PostMapping("/api/matches/calculate")
    public Match calculateMatch(@RequestBody MatchRequest request) {

        if (matchService.matchExists(
                request.lostItemId, request.foundItemId)) {

            return matchService.getAllMatches().stream()
                    .filter(m -> Objects.equals(
                            m.getLostItemId(), request.lostItemId)
                            && Objects.equals(
                            m.getFoundItemId(), request.foundItemId))
                    .findFirst()
                    .orElseThrow();
        }

        int score = matchService.calculateMatchScore(
                request.lostItemName,
                request.foundItemName,
                request.lostCategory,
                request.foundCategory,
                request.lostLocation,
                request.foundLocation,
                request.lostDate,
                request.foundDate,
                request.lostDescription,
                request.foundDescription
        );

        Match match = new Match();
        match.setLostItemId(request.lostItemId);
        match.setFoundItemId(request.foundItemId);
        match.setMatchScore(score);
        match.setMatchStatus(matchService.getMatchStatus(score));

        return matchService.saveMatch(match);
    }

    @GetMapping("/api/matches")
    public List<MatchResponse> getAllMatches() {

        List<LostItem> lostItems = lostItemService.getLostItems();
        List<FoundItem> foundItems = foundItemService.getFoundItems();

        // Compare every lost item with every found item.
        for (LostItem lost : lostItems) {
            for (FoundItem found : foundItems) {

                int score = matchService.calculateMatchScore(
                        lost.getItemName(),
                        found.getItemName(),
                        lost.getCategory(),
                        found.getCategory(),
                        lost.getLocation(),
                        found.getLocation(),
                        lost.getDateLost(),
                        found.getDateFound(),
                        lost.getDescription(),
                        found.getDescription()
                );

                // Save only possible and high matches.
                if (score >= 60 && !matchService.matchExists(
                        lost.getId(), found.getId())) {

                    Match match = new Match();
                    match.setLostItemId(lost.getId());
                    match.setFoundItemId(found.getId());
                    match.setMatchScore(score);
                    match.setMatchStatus(
                            matchService.getMatchStatus(score));

                    matchService.saveMatch(match);
                }
            }
        }

        List<Match> matches = matchService.getAllMatches();
        List<MatchResponse> result = new ArrayList<>();

        for (Match match : matches) {

            LostItem lost = lostItemService.getLostItemById(
                    match.getLostItemId());

            FoundItem found = foundItemService.getFoundItemById(
                    match.getFoundItemId());

            // Hide old matches that are no longer valid.
            if (lost == null || found == null) {
                continue;
            }

            int currentScore = matchService.calculateMatchScore(
                    lost.getItemName(),
                    found.getItemName(),
                    lost.getCategory(),
                    found.getCategory(),
                    lost.getLocation(),
                    found.getLocation(),
                    lost.getDateLost(),
                    found.getDateFound(),
                    lost.getDescription(),
                    found.getDescription()
            );

            // Do not return outdated or invalid matches.
            if (currentScore < 60) {
                continue;
            }

            // Update the stored score and status.
            if (match.getMatchScore() != currentScore) {
                match.setMatchScore(currentScore);
                match.setMatchStatus(
                        matchService.getMatchStatus(currentScore));
                matchService.saveMatch(match);
            }

            MatchResponse response = new MatchResponse();

            response.id = match.getId();
            response.lostItemId = match.getLostItemId();
            response.foundItemId = match.getFoundItemId();
            response.lostItemName = lost.getItemName();
            response.lostLocation = lost.getLocation();
            response.lostDate = lost.getDateLost();
            response.lostDescription = lost.getDescription();
            response.foundItemName = found.getItemName();
            response.foundLocation = found.getLocation();
            response.foundDate = found.getDateFound();
            response.foundDescription = found.getDescription();
            response.matchScore = currentScore;
            response.matchStatus = matchService.getMatchStatus(currentScore);

            result.add(response);
        }

        return result;
    }

    public static class MatchResponse {
        public Long id;
        public Long lostItemId;
        public Long foundItemId;
        public String lostItemName;
        public String lostLocation;
        public String lostDate;
        public String lostDescription;
        public String foundItemName;
        public String foundLocation;
        public String foundDate;
        public String foundDescription;
        public int matchScore;
        public String matchStatus;
    }

    public static class MatchRequest {
        public Long lostItemId;
        public Long foundItemId;
        public String lostItemName;
        public String foundItemName;
        public String lostCategory;
        public String foundCategory;
        public String lostLocation;
        public String foundLocation;
        public String lostDate;
        public String foundDate;
        public String lostDescription;
        public String foundDescription;
    }
}