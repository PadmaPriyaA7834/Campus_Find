
package com.campuslost.controller;

import com.campuslost.model.FoundItem;
import com.campuslost.model.LostItem;
import com.campuslost.model.Match;
import com.campuslost.service.FoundItemService;
import com.campuslost.service.LostItemService;
import com.campuslost.service.MatchService;
import com.campuslost.service.PhotoStorageService;

import java.io.IOException;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@CrossOrigin
@RestController
public class FoundItemController {

    private final FoundItemService foundItemService;
    private final LostItemService lostItemService;
    private final MatchService matchService;
    private final PhotoStorageService photoStorageService;

    public FoundItemController(
            FoundItemService foundItemService,
            LostItemService lostItemService,
            MatchService matchService,
            PhotoStorageService photoStorageService) {

        this.foundItemService = foundItemService;
        this.lostItemService = lostItemService;
        this.matchService = matchService;
        this.photoStorageService = photoStorageService;
    }

    @PostMapping("/api/found-items")
    public ResponseEntity<?> createFoundItem(
            @RequestParam String itemName,
            @RequestParam String category,
            @RequestParam String location,
            @RequestParam String dateFound,
            @RequestParam String description,
            @RequestParam(required = false) String contact,
            @RequestParam(required = false) MultipartFile photo) {

        try {
            FoundItem foundItem = new FoundItem();

            foundItem.setItemName(itemName.trim());
            foundItem.setCategory(category);
            foundItem.setLocation(location.trim());
            foundItem.setDateFound(dateFound);
            foundItem.setDescription(description.trim());
            foundItem.setContact(contact == null ? "" : contact.trim());
            foundItem.setStatus("FOUND");
            foundItem.setPhotoPath(photoStorageService.savePhoto(photo));

            FoundItem savedFoundItem =
                    foundItemService.saveFoundItem(foundItem);

            List<LostItem> lostItems =
                    lostItemService.getLostItems();

            for (LostItem lostItem : lostItems) {
                int score = matchService.calculateMatchScore(
                        lostItem.getItemName(),
                        savedFoundItem.getItemName(),
                        lostItem.getCategory(),
                        savedFoundItem.getCategory(),
                        lostItem.getLocation(),
                        savedFoundItem.getLocation(),
                        lostItem.getDateLost(),
                        savedFoundItem.getDateFound(),
                        lostItem.getDescription(),
                        savedFoundItem.getDescription()
                );

                if (score >= 60 && !matchService.matchExists(
                        lostItem.getId(), savedFoundItem.getId())) {

                    Match match = new Match();
                    match.setLostItemId(lostItem.getId());
                    match.setFoundItemId(savedFoundItem.getId());
                    match.setMatchScore(score);
                    match.setMatchStatus(matchService.getMatchStatus(score));
                    matchService.saveMatch(match);
                }
            }

            return ResponseEntity.ok(savedFoundItem);

        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Could not save the uploaded photo.");
        }
    }

    @GetMapping("/api/found-items")
    public List<FoundItem> getAllFoundItems() {
        return foundItemService.getFoundItems();
    }
}
