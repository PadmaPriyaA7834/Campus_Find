const CF_API = 'http://localhost:8080/api';
async function cfLoadAdminStats(){
 const targets=[['lostCount','/lost-items'],['foundCount','/found-items'],['matchCount','/matches'],['userCount','/users/count']];
 await Promise.all(targets.map(async ([id,path])=>{try{const res=await fetch(CF_API+path,{credentials:'include'});if(!res.ok)throw new Error('API '+res.status);const data=await res.json();const value=Array.isArray(data)?data.length:(typeof data==='number'?data:(data.count??data.total??data.totalUsers??0));document.getElementById(id).textContent=value;}catch(err){document.getElementById(id).textContent='—';console.warn('CampusFind stats unavailable:',path,err);}}));
}
const adminName=localStorage.getItem('userName')||sessionStorage.getItem('userName')||'Administrator';document.getElementById('adminName').textContent=adminName;document.getElementById('adminInitial').textContent=adminName.charAt(0).toUpperCase();cfLoadAdminStats();
document.getElementById('logoutLink').addEventListener('click',async e=>{e.preventDefault();try{await fetch(CF_API+'/users/logout',{method:'POST',credentials:'include'});}catch(_){}localStorage.clear();sessionStorage.clear();location.href='login.html';});
