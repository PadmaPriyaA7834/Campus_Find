
const API_BASE = "http://localhost:8080/api";
const IMAGE_BASE = "http://localhost:8080";

let allBrowseItems = [];

function readUserEmail() {
    const candidates = [
        localStorage.getItem("userEmail"),
        localStorage.getItem("email"),
        sessionStorage.getItem("userEmail"),
        sessionStorage.getItem("email")
    ];

    for (const candidate of candidates) {
        if (typeof candidate === "string" && candidate.trim()) {
            return candidate.trim();
        }
    }

    return "";
}

function isSameUserReport(item, savedEmail) {
    if (!savedEmail) return true;

    const normalizedEmail = normalizeValue(savedEmail);

    return (
        normalizeValue(item.contact) === normalizedEmail ||
        normalizeValue(item.email) === normalizedEmail ||
        normalizeValue(item.reporterEmail) === normalizedEmail ||
        normalizeValue(item.claimantEmail) === normalizedEmail
    );
}

// SHOW MESSAGE
function showMessage(elementId, message, type = "error") {
    const element = document.getElementById(elementId);
    if (!element) return;

    element.textContent = message;
    element.className =
        type === "success" ? "form-message success" : "form-message";
}

// ESCAPE HTML
function escapeBrowseHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, character => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[character]);
}

// NORMALIZE VALUES
function normalizeValue(value) {
    return String(value ?? "").trim().toLowerCase();
}

// REGISTER USER
async function registerUser(event) {
    event.preventDefault();
    showMessage("registerMessage", "");

    const name = document.getElementById("name")?.value.trim();
    const email = document.getElementById("email")?.value.trim();
    const password = document.getElementById("password")?.value;
    const confirmPassword =
        document.getElementById("confirmPassword")?.value;

    if (!name || !email || !password || !confirmPassword) {
        showMessage("registerMessage", "Please fill in all fields.");
        return;
    }

    if (password.length < 8) {
        showMessage(
            "registerMessage",
            "Password must contain at least 8 characters."
        );
        return;
    }

    if (password !== confirmPassword) {
        showMessage("registerMessage", "Passwords do not match.");
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/users`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                name,
                email,
                password,
                role: "STUDENT"
            })
        });

        if (response.ok) {
            alert("Registration successful!");
            window.location.href = "login.html";
        } else {
            showMessage(
                "registerMessage",
                "Registration failed. This email may already be registered."
            );
        }
    } catch (error) {
        console.error("Registration error:", error);
        showMessage(
            "registerMessage",
            "Unable to connect to the server."
        );
    }
}

// LOGIN USER
async function loginUser(event) {
    event.preventDefault();
    showMessage("loginMessage", "");

    const email =
        document.getElementById("loginEmail")?.value.trim();
    const password =
        document.getElementById("loginPassword")?.value;

    if (!email || !password) {
        showMessage("loginMessage", "Enter your email and password.");
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/users/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password })
        });

        if (response.ok) {
            const data = await response.json().catch(() => ({}));
            const userEmail = typeof data.email === "string" ? data.email.trim() : email;
            const userName = typeof data.name === "string" ? data.name : "";
            const userRole = typeof data.role === "string" ? data.role : "STUDENT";

            localStorage.setItem("userEmail", userEmail);
            localStorage.setItem("email", userEmail);
            localStorage.setItem("userName", userName);
            localStorage.setItem("userRole", userRole);
            sessionStorage.setItem("userEmail", userEmail);
            sessionStorage.setItem("email", userEmail);
            sessionStorage.setItem("userName", userName);
            sessionStorage.setItem("userRole", userRole);

            window.location.href = "dashboard.html";
        } else {
            showMessage("loginMessage", "Invalid email or password.");
        }
    } catch (error) {
        console.error("Login error:", error);
        showMessage(
            "loginMessage",
            "Unable to connect to the server."
        );
    }
}

// LOGOUT USER
async function logoutUser(event) {
    if (event) event.preventDefault();

    try {
        await fetch(`${API_BASE}/users/logout`, {
            method: "POST",
            credentials: "include"
        });
    } catch (error) {
        console.error("Logout error:", error);
    }

    localStorage.removeItem("userEmail");
    localStorage.removeItem("email");
    localStorage.removeItem("userName");
    localStorage.removeItem("userRole");
    sessionStorage.removeItem("userEmail");
    sessionStorage.removeItem("email");
    sessionStorage.removeItem("userName");
    sessionStorage.removeItem("userRole");

    window.location.href = "index.html";
}

// REPORT LOST ITEM
async function submitLostItem(event) {
    event.preventDefault();

    await submitItemReport({
        event,
        endpoint: `${API_BASE}/lost-items`,
        dateField: "dateLost",
        messageId: "lostItemMessage",
        successMessage: "Lost item reported successfully!"
    });
}

// REPORT FOUND ITEM
async function submitFoundItem(event) {
    event.preventDefault();

    await submitItemReport({
        event,
        endpoint: `${API_BASE}/found-items`,
        dateField: "dateFound",
        messageId: "foundItemMessage",
        successMessage: "Found item reported successfully!"
    });
}

// COMMON LOST/FOUND REPORT FUNCTION
async function submitItemReport({
    event,
    endpoint,
    dateField,
    messageId,
    successMessage
}) {
    const form = event.currentTarget;
    showMessage(messageId, "");

    const itemName = form.querySelector("#itemName")?.value.trim();
    const category = form.querySelector("#category")?.value;
    const location = form.querySelector("#location")?.value.trim();
    const itemDate = form.querySelector(`#${dateField}`)?.value;
    const description =
        form.querySelector("#description")?.value.trim();
    const contact = form.querySelector("#contact")?.value.trim();
    const photo = form.querySelector("#photo")?.files?.[0];

    if (!itemName || !category || !location || !itemDate || !description) {
        showMessage(messageId, "Please fill in all required fields.");
        return;
    }

    if (photo) {
        if (!photo.type.startsWith("image/")) {
            showMessage(messageId, "Please select an image file.");
            return;
        }

        if (photo.size > 5 * 1024 * 1024) {
            showMessage(messageId, "Image size must be below 5 MB.");
            return;
        }
    }

    const formData = new FormData();

    formData.append("itemName", itemName);
    formData.append("category", category);
    formData.append("location", location);
    formData.append(dateField, itemDate);
    formData.append("description", description);

    if (contact) formData.append("contact", contact);
    if (photo) formData.append("photo", photo);

    const submitButton = form.querySelector(
        'button[type="submit"], input[type="submit"]'
    );

    const originalText = submitButton
        ? (submitButton.textContent || submitButton.value)
        : "";

    if (submitButton) {
        submitButton.disabled = true;

        if (submitButton.tagName === "INPUT") {
            submitButton.value = "Submitting...";
        } else {
            submitButton.textContent = "Submitting...";
        }
    }

    try {
        const response = await fetch(endpoint, {
            method: "POST",
            body: formData
        });

        if (!response.ok) {
            throw new Error(`Request failed: ${response.status}`);
        }

        form.reset();
        showMessage(messageId, successMessage, "success");
    } catch (error) {
        console.error("Item report error:", error);

        showMessage(
            messageId,
            "Failed to submit the report. Please check the backend."
        );
    } finally {
        if (submitButton) {
            submitButton.disabled = false;

            if (submitButton.tagName === "INPUT") {
                submitButton.value = originalText;
            } else {
                submitButton.textContent = originalText;
            }
        }
    }
}

// LOAD LOST AND FOUND ITEMS FOR BROWSE
async function loadBrowseItems() {
    const itemsGrid = document.getElementById("itemsGrid");
    const loadingMessage = document.getElementById("loadingMessage");
    const noResults = document.getElementById("no-results");

    if (!itemsGrid) return;

    if (loadingMessage) {
        loadingMessage.textContent = "Loading items...";
        loadingMessage.style.display = "block";
    }

    try {
        const [lostResponse, foundResponse, matchesResponse] =
            await Promise.all([
                fetch(`${API_BASE}/lost-items`),
                fetch(`${API_BASE}/found-items`),
                fetch(`${API_BASE}/matches`)
            ]);

        if (!lostResponse.ok || !foundResponse.ok) {
            throw new Error("Unable to load items.");
        }

        const lostItems = await lostResponse.json();
        const foundItems = await foundResponse.json();

        let matches = [];

        if (matchesResponse.ok) {
            matches = await matchesResponse.json();
        }

        const returnedFoundItems = foundItems.filter(item =>
            normalizeValue(item.status) === "returned"
        );

        const returnedFoundIds = new Set(
            returnedFoundItems.map(item => String(item.id))
        );

        const resolvedLostIds = new Set();

        matches.forEach(match => {
            if (
                match.foundItemId != null &&
                match.lostItemId != null &&
                returnedFoundIds.has(String(match.foundItemId))
            ) {
                resolvedLostIds.add(String(match.lostItemId));
            }
        });

        // Hide lost reports linked to returned found items.
        const visibleLostItems = lostItems.filter(lostItem => {
            if (resolvedLostIds.has(String(lostItem.id))) {
                return false;
            }

            const hasReturnedMatch = returnedFoundItems.some(foundItem =>
                normalizeValue(foundItem.itemName) ===
                    normalizeValue(lostItem.itemName) &&
                normalizeValue(foundItem.category) ===
                    normalizeValue(lostItem.category) &&
                normalizeValue(foundItem.location) ===
                    normalizeValue(lostItem.location)
            );

            return !hasReturnedMatch;
        });

        allBrowseItems = [
            ...visibleLostItems.map(item => ({
                ...item,
                type: "LOST"
            })),
            ...foundItems.map(item => ({
                ...item,
                type: "FOUND"
            }))
        ];

        if (loadingMessage) {
            loadingMessage.style.display = "none";
        }

        displayBrowseItems(allBrowseItems);
    } catch (error) {
        console.error("Browse loading error:", error);

        if (loadingMessage) {
            loadingMessage.textContent =
                "Unable to load items. Please check the backend.";
            loadingMessage.style.display = "block";
        }

        if (noResults) noResults.style.display = "none";
    }
}

// CREATE PHOTO HTML
// Real uploaded photo = show it.
// No uploaded photo = show nothing.
function createItemImageHTML(item, itemName) {
    if (!item.photoPath) {
        return "";
    }

    const photoPath = /^https?:\/\//i.test(item.photoPath)
        ? item.photoPath
        : IMAGE_BASE + (
            item.photoPath.startsWith("/")
                ? item.photoPath
                : "/" + item.photoPath
        );

    return `
        <img
            class="item-photo"
            src="${escapeBrowseHTML(photoPath)}"
            alt="${escapeBrowseHTML(itemName || "Item photo")}"
            onerror="this.remove()"
        >
    `;
}

// DISPLAY BROWSE ITEMS
function displayBrowseItems(items) {
    const itemsGrid = document.getElementById("itemsGrid");
    const noResults = document.getElementById("no-results");

    if (!itemsGrid) return;

    itemsGrid.innerHTML = "";

    if (!items || items.length === 0) {
        if (noResults) noResults.style.display = "block";
        return;
    }

    if (noResults) noResults.style.display = "none";

    items.forEach(item => {
        const card = document.createElement("div");
        card.className = "item-card";

        const itemName = escapeBrowseHTML(
            item.itemName || "Unnamed item"
        );

        const category = escapeBrowseHTML(item.category || "Other");

        const location = escapeBrowseHTML(
            item.location || "Location not provided"
        );

        const description = escapeBrowseHTML(
            item.description || "No description"
        );

        const itemDate = item.type === "LOST"
            ? item.dateLost
            : item.dateFound;

        const detailsLink =
            "item-details.html?id=" +
            encodeURIComponent(item.id) +
            "&type=" +
            encodeURIComponent(item.type.toLowerCase());

        const status = normalizeValue(item.status);
        const statusLabel = status
            ? status.toUpperCase()
            : item.type;

        const statusClass = status === "returned"
            ? "returned"
            : item.type.toLowerCase();

        const imageHTML = createItemImageHTML(
            item,
            item.itemName
        );

        card.innerHTML = `
            ${imageHTML}

            <div class="item-content">
                <span class="item-status ${statusClass}">
                    ${escapeBrowseHTML(statusLabel)}
                </span>

                <h2>${itemName}</h2>
                <p>${category}</p>
                <p>${location}</p>
                <p>${escapeBrowseHTML(
                    itemDate || "Date not provided"
                )}</p>

                <p class="item-description">${description}</p>

                <a href="${detailsLink}" class="view-item">
                    View Details
                </a>
            </div>
        `;

        itemsGrid.appendChild(card);
    });
}

// SEARCH AND FILTER ITEMS
function searchItems() {
    const searchInput = document.getElementById("searchInput");
    const categoryFilter = document.getElementById("categoryFilter");
    const typeFilter = document.getElementById("typeFilter");

    if (!document.getElementById("itemsGrid")) {
        const searchBox = document.querySelector(".search-box input");
        const itemCard = document.querySelector(".item-card");
        const noResults = document.getElementById("no-results");

        if (!searchBox || !itemCard || !noResults) return;

        const searchText = searchBox.value.trim().toLowerCase();
        const itemName =
            itemCard.querySelector("h2")?.textContent.toLowerCase() || "";

        const found =
            searchText === "" || itemName.includes(searchText);

        itemCard.style.display = found ? "" : "none";
        noResults.style.display = found ? "none" : "block";
        return;
    }

    if (!searchInput || !categoryFilter || !typeFilter) return;

    const searchText = searchInput.value.trim().toLowerCase();
    const category = categoryFilter.value;
    const type = typeFilter.value;

    const filteredItems = allBrowseItems.filter(item => {
        const name = (item.itemName || "").toLowerCase();
        const description = (item.description || "").toLowerCase();
        const location = (item.location || "").toLowerCase();

        const matchesSearch =
            name.includes(searchText) ||
            description.includes(searchText) ||
            location.includes(searchText);

        const matchesCategory =
            category === "" ||
            normalizeValue(item.category) === normalizeValue(category);

        const matchesType =
            type === "" || normalizeValue(item.type) === normalizeValue(type);

        return matchesSearch && matchesCategory && matchesType;
    });

    displayBrowseItems(filteredItems);
}

// LOAD DASHBOARD STATISTICS
async function loadDashboardStats() {
    if (!document.getElementById("lostCount")) return;

    try {
        const [lostResponse, foundResponse, matchesResponse] =
            await Promise.all([
                fetch(`${API_BASE}/lost-items`),
                fetch(`${API_BASE}/found-items`),
                fetch(`${API_BASE}/matches`)
            ]);

        if (
            !lostResponse.ok ||
            !foundResponse.ok ||
            !matchesResponse.ok
        ) {
            throw new Error("Unable to load dashboard statistics.");
        }

        const lostItems = await lostResponse.json();
        const foundItems = await foundResponse.json();
        const matches = await matchesResponse.json();
        const savedEmail = readUserEmail();

        const myLostItems = savedEmail
            ? lostItems.filter(item => isSameUserReport(item, savedEmail))
            : lostItems;

        const myFoundItems = savedEmail
            ? foundItems.filter(item => isSameUserReport(item, savedEmail))
            : foundItems;

        document.getElementById("lostCount").textContent =
            myLostItems.length;

        const foundCount = document.getElementById("foundCount");
        if (foundCount) {
            foundCount.textContent = myFoundItems.length;
        }

        const matchCount = document.getElementById("matchCount");
        if (matchCount) {
            matchCount.textContent = matches.length;
        }
    } catch (error) {
        console.error("Dashboard statistics error:", error);
    }
}

// SUBMIT CLAIM — PRESERVED
async function submitClaim(event) {
    event.preventDefault();

    const form = event.currentTarget;

    const reason =
        document.getElementById("claimReason")?.value.trim();

    const proof =
        document.getElementById("claimProof")?.value.trim();

    const email =
        document.getElementById("claimEmail")?.value.trim();

    const params = new URLSearchParams(window.location.search);
    const matchId = Number(params.get("matchId"));

    if (!reason || !proof || !email) {
        showMessage("claimMessage", "Please fill in all fields.");
        return;
    }

    if (!Number.isInteger(matchId) || matchId <= 0) {
        showMessage("claimMessage", "Invalid match ID.");
        return;
    }

    const claim = {
        matchId,
        claimantName: "Student",
        claimantEmail: email,
        proof: `${reason} | ${proof}`,
        status: "PENDING"
    };

    try {
        const response = await fetch(`${API_BASE}/claims`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(claim)
        });

        if (!response.ok) {
            throw new Error(`Claim failed: ${response.status}`);
        }

        form.reset();

        showMessage(
            "claimMessage",
            "Claim submitted successfully!",
            "success"
        );
    } catch (error) {
        console.error("Claim submission error:", error);

        showMessage(
            "claimMessage",
            "Claim submission failed. Please try again."
        );
    }
}

// MY REPORTS
// Uses the existing #myReportsGrid container if present.
async function loadMyReports() {
    const reportsGrid = document.getElementById("myReportsGrid");
    if (!reportsGrid) return;

    reportsGrid.innerHTML = "<p>Loading your reports...</p>";

    try {
        const [lostResponse, foundResponse] = await Promise.all([
            fetch(`${API_BASE}/lost-items`),
            fetch(`${API_BASE}/found-items`)
        ]);

        if (!lostResponse.ok || !foundResponse.ok) {
            throw new Error("Unable to load reports.");
        }

        const lostItems = await lostResponse.json();
        const foundItems = await foundResponse.json();

        const savedEmail = readUserEmail();

        const combinedItems = [
            ...lostItems.map(item => ({ ...item, type: "lost" })),
            ...foundItems.map(item => ({ ...item, type: "found" }))
        ];

        const myItems = savedEmail
            ? combinedItems.filter(item => isSameUserReport(item, savedEmail))
            : combinedItems;

        reportsGrid.innerHTML = "";

        if (myItems.length === 0) {
            reportsGrid.innerHTML =
                "<p>No reports found.</p>";
            return;
        }

        myItems.forEach(item => {
            const card = document.createElement("div");
            card.className = "item-card";

            const itemName = escapeBrowseHTML(
                item.itemName || "Unnamed item"
            );

            const category = escapeBrowseHTML(
                item.category || "Other"
            );

            const location = escapeBrowseHTML(
                item.location || "Location not provided"
            );

            const description = escapeBrowseHTML(
                item.description || "No description"
            );

            const itemDate = item.type === "lost"
                ? item.dateLost
                : item.dateFound;

            const status = escapeBrowseHTML(
                item.status || item.type.toUpperCase()
            );

            const detailsLink =
                "item-details.html?id=" +
                encodeURIComponent(item.id) +
                "&type=" +
                encodeURIComponent(item.type);

            // No emoji placeholders in My Reports either.
            const imageHTML = createItemImageHTML(
                item,
                item.itemName
            );

            card.innerHTML = `
                ${imageHTML}

                <div class="item-content">
                    <span class="item-status ${item.type}">
                        ${status}
                    </span>

                    <h2>${itemName}</h2>
                    <p>${category}</p>
                    <p>${location}</p>
                    <p>${escapeBrowseHTML(
                        itemDate || "Date not provided"
                    )}</p>
                    <p class="item-description">${description}</p>

                    <a href="${detailsLink}" class="view-item">
                        View Details
                    </a>
                </div>
            `;

            reportsGrid.appendChild(card);
        });
    } catch (error) {
        console.error("My Reports loading error:", error);

        reportsGrid.innerHTML =
            "<p>Unable to load reports. Please check the backend.</p>";
    }
}

// PAGE INITIALIZATION
document.addEventListener("DOMContentLoaded", function () {
    if (document.getElementById("itemsGrid")) {
        loadBrowseItems();
    }

    if (document.getElementById("lostCount")) {
        loadDashboardStats();
    }

    if (document.getElementById("myReportsGrid")) {
        loadMyReports();
    }
});
