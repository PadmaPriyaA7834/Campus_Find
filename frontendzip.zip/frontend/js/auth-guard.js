(function(){
 const page=(location.pathname.split('/').pop()||'index.html').toLowerCase();
 const publicPages=['index.html','login.html','register.html'];
 const role=String(localStorage.getItem('userRole')||sessionStorage.getItem('userRole')||'STUDENT').toUpperCase();
 const email=localStorage.getItem('userEmail')||sessionStorage.getItem('userEmail')||localStorage.getItem('email')||sessionStorage.getItem('email');
 const loggedIn=Boolean(email);
 if(publicPages.includes(page)){
   if(loggedIn&&(page==='login.html'||page==='register.html')) location.replace(role==='ADMIN'?'admin.html':'dashboard.html');
   return;
 }
 if(!loggedIn){location.replace('login.html?return='+encodeURIComponent(page));return;}
 if(page==='admin.html'&&role!=='ADMIN'){location.replace('dashboard.html');return;}
 if(page!=='admin.html'&&role==='ADMIN'&&page==='dashboard.html'){location.replace('admin.html');return;}
 document.querySelectorAll('#logoutLink').forEach(link=>link.addEventListener('click',async function(ev){
   if(link.getAttribute('href')==='index.html'){ev.preventDefault();try{await fetch('http://localhost:8080/api/users/logout',{method:'POST',credentials:'include'});}catch(_){}localStorage.clear();sessionStorage.clear();location.replace('login.html');}
 }));
})();
